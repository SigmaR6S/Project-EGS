<section class="row wrap x-center">
    <div class="xLarge-4 large-4 medium-6 small-12 xSmall-12">
        <div class="padd-around">
            <form id="contact-form" method="post">
                <p class="title">Contacter Nous !</p>
                <label>Email</label>
                <input type="email" name="email" placeholder="Votre e-mail..." required spellcheck="false" autocomplete="off">
                <label>Sujet</label>
                <input type="text" name="subject" placeholder="Votre sujet..." required spellcheck="false" autocomplete="off">
                <label>Message</label>
                <textarea placeholder="Votre message..." name="message"></textarea>
                <button type="submit" class="btns">Envoyer</button>
            </form>
        </div>
    </div>
</section>