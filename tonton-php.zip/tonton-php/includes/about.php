<?php

echo '&Agrave; propos';
